import { Component } from '@angular/core';

import { ProductService } from './app.productservice'
import { Product } from './product';

@Component({
    selector: 'product-app',
    templateUrl: './app.product.html',
    styleUrls: ['./app.product.css'],
    providers: [ProductService]
})

export class ProductComponent {

    p: number = 1;
    model: any = {};
    up: any = {};
    Products: Product[];
    constructor(private getAllProducts: ProductService) { }   //DI
    ngOnInit(): any {
        this.getAllProducts.getAllProducts().subscribe((data: Product[]) => this.Products = data);
    }

    addDetails(): any {
        var reg=/^[a-z]+$/;
        var reg1 = /^[0-9]+$/;
       
        if(this.model.price.match(reg))
        {
            
            alert("Price should be a numeric value");
        }  
        else if(this.model.id.match(reg)) 
        {
            alert("ID should be a numeric value")
        }
        else if(this.model.name.match(reg1)) 
        {
            alert("Name should not be a numeric value")
        }
        else if(this.model.description.match(reg1)) 
        {
            alert("Description should not be a numeric value")
        }
       else if(this.model.id==""||this.model.name==""||this.model.description==""||this.model.price=="")
        {
            alert("Enter the values")
        }
        else{
            alert("Item added")
        this.Products.push(this.model)
        this.model = {};
        }
    
    }


    update(eid: number): any {
        for (let i in this.Products) {
            if (this.Products[i].id == eid) {
                this.up = this.Products[i];
            }

        }


    }
    updatenew(): any {
        this.up.id = (document.getElementById("a") as HTMLInputElement).value;
        this.up.name = (document.getElementById("b") as HTMLInputElement).value;
        this.up.description = (document.getElementById("c") as HTMLInputElement).value;
        this.up.price = (document.getElementById("d") as HTMLInputElement).value;

        this.up = {}
    }
    delete(eid: number): any {
        for (let i in this.Products) {
            if (this.Products[i].id == eid) {
                this.Products.splice(Number(i), 1);
            }

        }
    }
    deleteAll(): any {


        this.Products.splice(0, this.Products.length);
        alert("Data Deleted")
    }

    

    
}

